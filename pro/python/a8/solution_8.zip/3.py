for i in range(1,11):
    if i==6:
        continue
    else:
        print(i)
