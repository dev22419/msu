set={"one","two","three","four","five","six"}
print(type(set))
print("This is a set :",set)
