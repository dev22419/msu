tup1=("h","i","j","k","l")
tup2=(1,2,3,4,5,tup1)
print("This is a nested tuple with tup1 and tup2 :\n",tup2)