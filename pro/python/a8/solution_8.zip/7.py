Newlist = []
for x in range(1,1000):
   res=x**2
   Newlist.append(res)      
print(Newlist)
