# bitwise operaters

a = 10
b = 12

# AND operator
print(a & b)

# OR operator
print(a | b)

# NOT operator
print(~a)

# XOR operator
print(a ^ b)

# LEFT SHIFT operator
print(a << b)

# RIGHT SHIFT operator
print(a >> b)
