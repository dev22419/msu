x=["l1","l2","l3","l4","l5"]
y=tuple(x)

print(type(y))
for i in y:
    print(i)