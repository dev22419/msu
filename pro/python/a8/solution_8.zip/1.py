x = input("Enter variable :").split(",")
print(x)
