Newlist = []
for x in range(1,1000):
   if x % 5 == 0:
      Newlist.append(x)      
print(Newlist)
