tup1=("h","i","j","k","l")
tup2=(1,2,3,4,5)
x=tup1+tup2
# tup2=(1,2,3,4,5,tup1)
# print("This is a nested tuple with tup1 and tup2 :\n",tup2)
for i in x:
     print(i)