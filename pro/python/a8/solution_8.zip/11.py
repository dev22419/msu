tup1=("t1","t2","t3","t4","t5")
tup2=("y1","y2","y3","y4","y5")
w=tup1+tup2
print(tup1)
print(tup2)
print("The Concatenate of two tuple is : ",w)