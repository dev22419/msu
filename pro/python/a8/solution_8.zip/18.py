set={"one","two","three","four","five"}
for i in set:
    print(i)