set={"one","two","three","four","five"}
print("Printing set :",set)