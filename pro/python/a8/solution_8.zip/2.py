for i in range(1,11):
    if i==8:
        break
    else:
        print(i)
