# identity operates
x = 55
y = 55

if x is y :
    print("both the variable have the same values")
else :
    print("both the variable don't have the same values")

y = 45

if x is not y :
    print("both the variable don't have the same values")
else :
    print("both the variable don't have the same values")
