row = 10

for i in range(1 , row+1):
    for j in range(1, 11):
        print(i*j  , end=" ")
    print(" ")