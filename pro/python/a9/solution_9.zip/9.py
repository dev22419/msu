row = 5
n = 1

for i in range(1 , row + 1):
    for j in range(1 , 6):
        print( 1 , end=" ")
    print(" ")