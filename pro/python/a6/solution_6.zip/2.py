
n = int(input("Enter the number: "))

for i in range(1, 11):
    print(n, "x", i, "=", n * i)
