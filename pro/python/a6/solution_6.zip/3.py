
n=int(input("Multiplication Table of:"))
m=int(input("Till:"))
for i in range(1,m+1):
    print("{} X {} = {}".format(i,n,i*n))
