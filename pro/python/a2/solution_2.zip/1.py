#Program to swep two numbers
p=int(input("Please enter value for p:"))
q=int(input("please enter value for q:"))
temp_1=p
p=q
q=temp_1
print("The Value of p after swapping:",p)
print("The value of q after swapping:",q)
