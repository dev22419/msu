#program to take two numbers from the user, print the sum.
firstNum= float(input("Enter First Number: "))
secNum = float(input("Enter Second Number : "))

#Adding the numbers
total = firstNum + secNum
#printing the output
print("Addition of",int(firstNum),"and",int(secNum),"is =",int(total))

