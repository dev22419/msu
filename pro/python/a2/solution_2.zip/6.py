#program to enter your name and display your name n no of times.
name=input("Enter your name: ")
n=int(input("Enter the no of times:"))
print(name * n)

