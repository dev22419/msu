#program print 100 blank lines on your screen.
print("\n"  *  100)
print("")
print("\n\n\n\n\n")
print("End of this 100 Blank lines")

