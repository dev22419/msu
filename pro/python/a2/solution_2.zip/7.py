'''program that prompts the user to enter the first name. Then display the following message.
Hello firstname
Welcome to Python
'''
name=input("Enter your first name:")
print("Hello",name+"!")
print("")
print("\nWelcome to Python !")

