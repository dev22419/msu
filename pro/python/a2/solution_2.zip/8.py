#Python program to print the following string
print("\tTwinkle,twinkle,little star,")
print("\t\tHow I wonder what yu are!")
print("\t\t\tUp above the world so")
print("  high,")
print("\t\t\tLike a dimond in the sky.")
print("\tTwinkle,twinkle,little star,")
print("\t\tHow I wonder what yu are!")
print("\n")
print("     Twinkle, twinkle, little star,\n\tHow I wonder what you are!\n\t\tUp above the world so \nhigh, \n\t\tlike a diamond in the sky.\n     Twinkle, twinkle, little star,\n\tHow I wonder what you are")

