# code by : dev patel
# https://www.github.com/dev22419/

#assigning two integer values
a = 5
b = 2

# addition
print(a + b)

# subtraction
print(a - b)

# multiplication
print(a * b)

# divison
print(a / b)

# remainder
print(a % b)

# floor divison
print(a // b)

# exponant / raise to
print(a ** b)

#assigning two float values
a = 5.4
b = 2.8

# addition
print(a + b)

# subtraction
print(a - b)

# multiplication
print(a * b)

# divison
print(a / b)

# remainder
print(a % b)

# floor divison
print(a // b)

# exponant / raise to
print(a ** b)