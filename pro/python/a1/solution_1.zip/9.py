# code by : dev patel
# https://www.github.com/dev22419/

# taking a integer variable
x = 5

# using the operaters

# adding
x += 2
print(x)

# sub
x -= 2
print(x)

# multi
x *= 2
print(x)

# div
x /= 2
print(x)

# remainder
x %= 2
print(x)

# floor div
x //= 2
print(x)

# square
x  **= 2
print(x = 5)
