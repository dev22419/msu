# code by : dev patel
# https://www.github.com/dev22419/

print("Class by \"M S University\" is very good.")

print("Class by \"M S University\" for \'python\' is very good.")

print("""FYBCA
Semester 1
python
""")