# code by : dev patel
# https://www.github.com/dev22419/

# area of circle = pie*r**2

# takinng input from users 

pie = 22/7
r = int(input("type the radius of circle : "))

# calculating

area = pie*r**2
area = str(area)

# output
print("")
print("area of the circle is \"" + area[:5] + "\".")