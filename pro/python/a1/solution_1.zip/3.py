# code by : dev patel
# https://www.github.com/dev22419/

a = "hello"
b= "world"

print(a + " " + b)