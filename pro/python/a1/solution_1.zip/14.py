# code by : dev patel
# https://www.github.com/dev22419/

# assigning variables 
x = "msu "
y = "is good"
z = 5

# addition of strings 
print(x+y)

# mulltiplication of string 
print(x*z)