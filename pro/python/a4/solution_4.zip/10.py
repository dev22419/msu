cel = float(input("Enter temperature in Celsius: "))
fahren = (cel * 9/5) + 32
print( "Temperature in fahrenheit is ", fahren )
