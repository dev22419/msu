#Printing the type of variable
a=5
b=10.5
c="FYBCA"
print("Data type of num int:",type(a))
print("Data type of num float:",type(b))
print("Data type of num str:",type(c))
