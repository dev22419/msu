a=int(input("Enter a number : "))
if(a>0)and(a<101):
    print("{} is between 1 to 100".format(a))
else:
    print("{} is not between 1 to 100".format(a))
