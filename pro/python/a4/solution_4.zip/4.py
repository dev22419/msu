#Program to find the largest number
num1=int(input("Enter the first number : "))
num2=int(input("Enter the second bumber : "))

if(num1>num2):
    print("{} is largest".format(num1))
else:
    print("{} is largest".format(num2))
