str='Pyhton is Easy !!!'
print(str)              #Python is Easy!!!
print(str[0])           #P
print(str[:-1])         #Python is Easy!!
print(str[:])           #python is Easy!!!
print(str[-3])          #~!
print(str[3:9])         #ton is
print(str[:5])          #Pytho
print(str[0:])          #Python is Easy!!!
print(str*2)            #python is Easy!!!python is Easy!!!
print(str+"Isn't it")   #python is Easy!!!Isn't it
print(str[0:])          #python is Easy!!!
str[3]="X"              #Error
print(str)              #Error
