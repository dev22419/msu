age=36
txt="My name is Rahul,and I am {}"
print(txt.format(age))
