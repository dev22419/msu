# code by : dev patel
# https://www.github.com/dev22419/

# list variable
x = ["html","msu","javascrpit","database","php","node.js"]
print(x)

if "msu" in x:
    print("yes")
else :
    print("no")