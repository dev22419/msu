# code by : dev patel
# https://www.github.com/dev22419/

# delet the item in even place

# list variable
x = ["python","c","c++","ruby","html","java",".net","c#","swift","kotil","matlab"]
print(x)

del x[0::2]

print(x)