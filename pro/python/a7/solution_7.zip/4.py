# code by : dev patel
# https://www.github.com/dev22419/

# making a list 
x = [1, "A", 'MSU', 123, 909, 78.88, 77, 6544, 78.50, 7+9j, True, False, 900000, "XYZ", 90.99999999999]

# printing and slicing
print(x)
print(x[6])
print(x[-2])
print(x[-10])
print(x[0:6])
print(x[1:6])
print(x[6:10])
print(x[:])
print(x[::])
print(x[::-1])
print(x[:10])
print(x[::2])
print(x[0::1])
print(x[2:13:4])
