# code by : dev patel
# https://www.github.com/dev22419/

x = ["html","css","msu","javascrpit","msu","database","php","msu","node.js"]
print(x)

# main code 
count = 0

for i in x:
    if i == "msu":
        count = count + 1
    else:
        pass
print("msu is repeated" , count , "times .")