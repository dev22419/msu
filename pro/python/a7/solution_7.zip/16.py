# code by : dev patel
# https://www.github.com/dev22419/

list1 = ["abc","2",34,89,"ZZ",4.534]
list2 = [1,89,"Krish", "Python", True, 2+8j]
list3 = ["abc","2",34,89,"ZZ",4.534, [2,3,4], 809]

print(list1,list2,list3, sep =",")
list4 = list1+list2

print(list4)
