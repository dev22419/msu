# code by : dev patel
# https://www.github.com/dev22419/

x = ["html","css","javascrpit","database","php","node.js"]

y = x

print(x)
print(y)