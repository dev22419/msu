# code by : dev patel
# https://www.github.com/dev22419/

# making list
x = ["html","css","javascrpit","database","php","node.js"]
y = ["vs code","atom","eclipse","sublime"]

z = ["python","ruby","c","c++","c#","java",x,y]

print(z)
