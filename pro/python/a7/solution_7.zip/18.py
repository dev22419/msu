# code by : dev patel
# https://www.github.com/dev22419/

myL =  [1,2,3]
myL2 = [1,2,3]
myL[1] =myL2
print(myL)
