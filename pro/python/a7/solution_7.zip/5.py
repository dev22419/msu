# code by : dev patel
# https://www.github.com/dev22419/

# list varaiable
x = ["python","c","c++","ruby","html","java",".net","c#","swift","kotil","matlab"]
print(x)

# deleting an item with pop() keyword
x.pop(1)
print(x)

# deleting an item with remove() keyword
x.remove("ruby")
print(x)

# deleting an item with del() keyword
del x[8]
print(x)