# code by : dev patel
# https://www.github.com/dev22419/

# list variable
x = ["1","2","3","4","5","6","7"]
print(x)
print(type(x))

# coverting list to tuple / type casting
x = tuple(x)
print(x)
print(type(x))

