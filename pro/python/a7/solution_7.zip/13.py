# code by : dev patel
# https://www.github.com/dev22419/

# list variable
x = ["html","css","javascrpit","database","php","node.js"]
print(x)

# inserting the value
x.insert(3 ,"MSU")
print(x)