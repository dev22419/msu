# code by : dev patel
# https://www.github.com/dev22419/

# making variable
x = ["python","c","c++","ruby","html","java",".net","c#","swift","kotil","matlab"]
print(x)

# deleting the definition of list
x.clear()
print(x)