# code by : dev patel
# https://www.github.com/dev22419/

# making to list x and y
x = ["python" , "c" , "c++"]
print(x)
y = ["ruby" , "shell script" , "mangodb" , "html"]
print(y)

# combining list togather
x.extend(y)

# output
print(x)