# code by : dev patel
# https://www.github.com/dev22419/

# delet the item in odd place

# list variable
x = ["python","c","c++","ruby","html","java",".net","c#","swift","kotil","matlab"]
print(x)

del x[1::2]

print(x)