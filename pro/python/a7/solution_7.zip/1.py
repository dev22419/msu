# code by : dev patel
# https://www.github.com/dev22419/

# assigning the list variable

x = ["dev","om","ayush",1,1.5,1j,True,False]

# printing the list

print(x)