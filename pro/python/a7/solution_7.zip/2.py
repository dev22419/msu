# code by : dev patel
# https://www.github.com/dev22419/

# assigning the list variable
x = ["windows 7","windows 10","windows 11","kali linux","ubuntu","android","mac os","ios"]
print(x)

# looping and printing the list item
for i in x:
    print(i)