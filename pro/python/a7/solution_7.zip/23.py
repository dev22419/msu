# code by : dev patel
# https://www.github.com/dev22419/

x = "python"
print (x)   
r= ""  
count = len(x) 
while count > 0:   
    r += x[ count - 1 ]  
    count = count - 1  
print (r)