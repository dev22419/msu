# code by : dev patel
# https://www.github.com/dev22419/

# list variable
x = ["python","c","c++","ruby","html","java",".net","c#","swift","kotil"]
print(x)

# changing the list items
x[1] = "dbms"
print(x)

x[1:4] = "matlab"
print(x)

# inserting the items
x.insert(3 , "mangodb")
print(x)

# add items
x.append("css")
print(x)

# removing the items
x.remove("python")
print(x)