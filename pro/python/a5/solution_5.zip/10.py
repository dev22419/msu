i=11
while(i>=1):
    i=i-1
    print(i,end="\t")
