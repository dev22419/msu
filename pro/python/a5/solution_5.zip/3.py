count=0
while(count<3):
    print("Hello world")
    count=count+1

