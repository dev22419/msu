

# For obtaining list of random numbers
import random
randomlist=[]
for a in range(0,4):
    q=random.randint(1,30)
    randomlist.append(q)
print(randomlist)


#For obtaining single random number
import random
print(random.randint(1,10))
