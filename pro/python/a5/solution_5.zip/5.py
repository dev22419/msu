#Using for loop
print('Numbers from 1 to 100 : ')
for n in range(1,101):
    print(n,end='\t')


#Using while loop
print('\nNumber from 1 to 100 : ')
n=1
while n<=100:
        print(n,end='\t')
        n=n+1
