for num in range(2,22,2):
    print(num)
