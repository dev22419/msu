for num in range(2,102,2):
    print(num)
